package com.experiment5.model;

/**
 * Enumeration representing the lifecycle states of a social post.
 */
public enum PostStatus {
    DRAFT,
    SCHEDULED,
    PUBLISHED,
    ARCHIVED
}
