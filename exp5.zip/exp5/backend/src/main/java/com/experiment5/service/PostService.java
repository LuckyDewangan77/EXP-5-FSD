package com.experiment5.service;

import com.experiment5.dto.PostRequest;
import com.experiment5.dto.SchedulePostRequest;
import com.experiment5.model.Post;
import com.experiment5.model.PostStatus;

import java.util.List;

/**
 * Service interface defining business logic operations for posts.
 */
public interface PostService {
    Post createPost(PostRequest request);
    List<Post> getAllPosts(PostStatus status, String search);
    Post getPostById(Long id);
    Post updatePost(Long id, PostRequest request);
    void deletePost(Long id);
    Post schedulePost(Long id, SchedulePostRequest request);
    Post publishPost(Long id);
}
