package com.experiment5.service;

import com.experiment5.dto.PostRequest;
import com.experiment5.dto.SchedulePostRequest;
import com.experiment5.exception.InvalidScheduleException;
import com.experiment5.exception.ResourceNotFoundException;
import com.experiment5.model.Post;
import com.experiment5.model.PostStatus;
import com.experiment5.repository.PostRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service implementation managing post business logic, validation, and lifecycle state transitions.
 */
@Service
public class PostServiceImpl implements PostService {

    private static final Logger log = LoggerFactory.getLogger(PostServiceImpl.class);
    private final PostRepository postRepository;

    public PostServiceImpl(PostRepository postRepository) {
        this.postRepository = postRepository;
    }

    @Override
    public Post createPost(PostRequest request) {
        log.info("Creating post with title: '{}', author: '{}'", request.getTitle(), request.getAuthor());
        Post post = new Post();
        post.setTitle(request.getTitle());
        post.setContent(request.getContent());
        post.setAuthor(request.getAuthor());
        post.setStatus(PostStatus.DRAFT);
        Post saved = postRepository.save(post);
        log.info("Successfully created post with ID: {}", saved.getId());
        return saved;
    }

    @Override
    public List<Post> getAllPosts(PostStatus status, String search) {
        log.info("Fetching all posts with filter [status: {}, search: '{}']", status, search);
        List<Post> posts = postRepository.findAll();

        return posts.stream()
                .filter(p -> status == null || p.getStatus() == status)
                .filter(p -> search == null || search.isBlank() ||
                        p.getTitle().toLowerCase().contains(search.toLowerCase()) ||
                        p.getContent().toLowerCase().contains(search.toLowerCase()) ||
                        p.getAuthor().toLowerCase().contains(search.toLowerCase()))
                .sorted(Comparator.comparing(Post::getId).reversed())
                .collect(Collectors.toList());
    }

    @Override
    public Post getPostById(Long id) {
        log.info("Fetching post by ID: {}", id);
        return postRepository.findById(id)
                .orElseThrow(() -> {
                    log.warn("Post lookup failed - post not found with ID: {}", id);
                    return new ResourceNotFoundException("Post not found with ID: " + id);
                });
    }

    @Override
    public Post updatePost(Long id, PostRequest request) {
        log.info("Updating post with ID: {}", id);
        Post post = getPostById(id);
        post.setTitle(request.getTitle());
        post.setContent(request.getContent());
        post.setAuthor(request.getAuthor());
        Post updated = postRepository.save(post);
        log.info("Post ID: {} successfully updated", id);
        return updated;
    }

    @Override
    public void deletePost(Long id) {
        log.info("Deleting post with ID: {}", id);
        if (!postRepository.existsById(id)) {
            log.warn("Cannot delete - post not found with ID: {}", id);
            throw new ResourceNotFoundException("Post not found with ID: " + id);
        }
        postRepository.deleteById(id);
        log.info("Post ID: {} successfully deleted", id);
    }

    @Override
    public Post schedulePost(Long id, SchedulePostRequest request) {
        log.info("Scheduling post ID: {} for {}", id, request.getScheduledAt());
        Post post = getPostById(id);

        if (post.getStatus() == PostStatus.ARCHIVED) {
            log.warn("Scheduling rejected: Post ID {} is archived", id);
            throw new InvalidScheduleException("Cannot schedule an archived post.");
        }

        if (request.getScheduledAt().isBefore(LocalDateTime.now())) {
            log.warn("Scheduling rejected: Time {} is in the past", request.getScheduledAt());
            throw new InvalidScheduleException("Scheduled time must be in the future.");
        }

        post.setScheduledAt(request.getScheduledAt());
        post.setStatus(PostStatus.SCHEDULED);
        Post scheduled = postRepository.save(post);
        log.info("Post ID: {} successfully scheduled for {}", id, scheduled.getScheduledAt());
        return scheduled;
    }

    @Override
    public Post publishPost(Long id) {
        log.info("Publishing post ID: {}", id);
        Post post = getPostById(id);
        post.setStatus(PostStatus.PUBLISHED);
        Post published = postRepository.save(post);
        log.info("Post ID: {} published successfully", id);
        return published;
    }
}
