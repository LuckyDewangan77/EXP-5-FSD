package com.experiment5.exception;

/**
 * Exception thrown when a post schedule operation is invalid due to state or logic constraints.
 */
public class InvalidScheduleException extends RuntimeException {
    public InvalidScheduleException(String message) {
        super(message);
    }
}
