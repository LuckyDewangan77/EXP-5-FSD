package com.experiment5.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * DTO for creating and updating posts.
 * Enforces input data constraints using Jakarta Bean Validation.
 */
public class PostRequest {

    @NotBlank(message = "Title must not be empty")
    @Size(min = 3, max = 100, message = "Title must be between 3 and 100 characters")
    private String title;

    @NotBlank(message = "Content must not be empty")
    @Size(max = 280, message = "Content exceeds limit of 280 characters")
    private String content;

    @NotBlank(message = "Author must not be empty")
    private String author;

    public PostRequest() {}

    public PostRequest(String title, String content, String author) {
        this.title = title;
        this.content = content;
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
}
