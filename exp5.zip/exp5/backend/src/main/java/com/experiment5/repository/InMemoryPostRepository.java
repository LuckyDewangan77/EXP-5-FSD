package com.experiment5.repository;

import com.experiment5.model.Post;
import com.experiment5.model.PostStatus;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * Thread-safe in-memory implementation of PostRepository.
 * Preloads realistic sample posts for immediate testing and demonstration.
 */
@Repository
public class InMemoryPostRepository implements PostRepository {

    private final Map<Long, Post> storage = new ConcurrentHashMap<>();
    private final AtomicLong idGenerator = new AtomicLong(1);

    public InMemoryPostRepository() {
        initSampleData();
    }

    private void initSampleData() {
        save(new Post(
                null,
                "Spring Boot 4.0 Architecture",
                "Exploring the layered architecture pattern in modern Spring applications with clean separation of concerns.",
                "Alice Engineer",
                PostStatus.PUBLISHED,
                null
        ));

        save(new Post(
                null,
                "Upcoming Tech Webinar Announcement",
                "Join our deep-dive session on distributed tracing with SLF4J MDC and correlation IDs this Friday!",
                "Bob Architect",
                PostStatus.SCHEDULED,
                LocalDateTime.now().plusDays(2).withHour(15).withMinute(0).withSecond(0)
        ));

        save(new Post(
                null,
                "Draft: API Design Best Practices",
                "Notes on idempotency, HTTP status codes, and Bean Validation constraints for scalable microservices.",
                "Charlie Dev",
                PostStatus.DRAFT,
                null
        ));
    }

    @Override
    public Post save(Post post) {
        if (post.getId() == null) {
            post.setId(idGenerator.getAndIncrement());
            post.setCreatedAt(LocalDateTime.now());
        }
        post.setUpdatedAt(LocalDateTime.now());
        storage.put(post.getId(), post);
        return post;
    }

    @Override
    public Optional<Post> findById(Long id) {
        return Optional.ofNullable(storage.get(id));
    }

    @Override
    public List<Post> findAll() {
        return new ArrayList<>(storage.values());
    }

    @Override
    public List<Post> findByStatus(PostStatus status) {
        return storage.values().stream()
                .filter(post -> post.getStatus() == status)
                .collect(Collectors.toList());
    }

    @Override
    public boolean deleteById(Long id) {
        return storage.remove(id) != null;
    }

    @Override
    public boolean existsById(Long id) {
        return storage.containsKey(id);
    }

    @Override
    public long count() {
        return storage.size();
    }
}
