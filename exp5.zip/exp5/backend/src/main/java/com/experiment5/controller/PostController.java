package com.experiment5.controller;

import com.experiment5.dto.ApiResponse;
import com.experiment5.dto.PostRequest;
import com.experiment5.dto.SchedulePostRequest;
import com.experiment5.model.Post;
import com.experiment5.model.PostStatus;
import com.experiment5.service.PostService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller exposing endpoints for Post resource management and scheduling.
 * Implements RESTful semantics, layered delegation, Bean Validation, and standardized response wrappers.
 */
@RestController
@RequestMapping("/api/posts")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173"})
public class PostController {

    private final PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    /**
     * Create a new post.
     * Enforces Bean Validation on incoming PostRequest payload.
     *
     * @param request Validated PostRequest DTO
     * @return 201 Created with standardized ApiResponse
     */
    @PostMapping
    public ResponseEntity<ApiResponse<Post>> createPost(@Valid @RequestBody PostRequest request) {
        Post created = postService.createPost(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Post created successfully", created));
    }

    /**
     * Retrieve all posts, with optional status and search filtering.
     *
     * @param status Optional post status filter (DRAFT, SCHEDULED, PUBLISHED, ARCHIVED)
     * @param search Optional keyword search across title, content, and author
     * @return 200 OK with list of posts wrapped in ApiResponse
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<Post>>> getAllPosts(
            @RequestParam(required = false) PostStatus status,
            @RequestParam(required = false) String search) {
        List<Post> posts = postService.getAllPosts(status, search);
        return ResponseEntity.ok(ApiResponse.success("Posts retrieved successfully", posts));
    }

    /**
     * Retrieve a single post by its unique ID.
     *
     * @param id Unique post identifier
     * @return 200 OK with Post wrapped in ApiResponse
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Post>> getPostById(@PathVariable Long id) {
        Post post = postService.getPostById(id);
        return ResponseEntity.ok(ApiResponse.success("Post retrieved successfully", post));
    }

    /**
     * Update an existing post by ID.
     *
     * @param id Post identifier to update
     * @param request Validated updated fields
     * @return 200 OK with updated Post
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Post>> updatePost(
            @PathVariable Long id,
            @Valid @RequestBody PostRequest request) {
        Post updated = postService.updatePost(id, request);
        return ResponseEntity.ok(ApiResponse.success("Post updated successfully", updated));
    }

    /**
     * Delete a post by ID.
     *
     * @param id Post identifier to delete
     * @return 200 OK confirming deletion
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deletePost(@PathVariable Long id) {
        postService.deletePost(id);
        return ResponseEntity.ok(ApiResponse.success("Post deleted successfully", null));
    }

    /**
     * Schedule a post for future publication.
     * Enforces future timestamp validation.
     *
     * @param id Post identifier to schedule
     * @param request Validated SchedulePostRequest with future date/time
     * @return 200 OK with scheduled post details
     */
    @PostMapping("/{id}/schedule")
    public ResponseEntity<ApiResponse<Post>> schedulePost(
            @PathVariable Long id,
            @Valid @RequestBody SchedulePostRequest request) {
        Post scheduled = postService.schedulePost(id, request);
        return ResponseEntity.ok(ApiResponse.success("Post scheduled successfully", scheduled));
    }

    /**
     * Immediately publish a post.
     *
     * @param id Post identifier to publish
     * @return 200 OK with published post details
     */
    @PostMapping("/{id}/publish")
    public ResponseEntity<ApiResponse<Post>> publishPost(@PathVariable Long id) {
        Post published = postService.publishPost(id);
        return ResponseEntity.ok(ApiResponse.success("Post published successfully", published));
    }
}
