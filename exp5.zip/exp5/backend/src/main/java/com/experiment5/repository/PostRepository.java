package com.experiment5.repository;

import com.experiment5.model.Post;
import com.experiment5.model.PostStatus;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface defining persistence operations for Post entities.
 */
public interface PostRepository {
    Post save(Post post);
    Optional<Post> findById(Long id);
    List<Post> findAll();
    List<Post> findByStatus(PostStatus status);
    boolean deleteById(Long id);
    boolean existsById(Long id);
    long count();
}
