package com.experiment5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exp5RestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Exp5RestApiApplication.class, args);
	}

}
