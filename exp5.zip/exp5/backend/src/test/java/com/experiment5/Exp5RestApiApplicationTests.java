package com.experiment5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exp5RestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
