package com.experiment5.controller;

import com.experiment5.dto.PostRequest;
import com.experiment5.dto.SchedulePostRequest;
import com.experiment5.interceptor.CorrelationInterceptor;
import tools.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class PostControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @DisplayName("GET /api/posts - Retrieve all posts wrapped in standardized ApiResponse")
    void getAllPosts_Success() throws Exception {
        mockMvc.perform(get("/api/posts")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(header().exists(CorrelationInterceptor.CORRELATION_ID_HEADER))
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.message").value("Posts retrieved successfully"))
                .andExpect(jsonPath("$.data", hasSize(greaterThanOrEqualTo(1))));
    }

    @Test
    @DisplayName("GET /api/posts/{id} - Retrieve existing post by ID")
    void getPostById_Success() throws Exception {
        mockMvc.perform(get("/api/posts/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data.id").value(1))
                .andExpect(jsonPath("$.data.title").isNotEmpty());
    }

    @Test
    @DisplayName("GET /api/posts/{id} - Non-existent ID returns 404 handled globally")
    void getPostById_NotFound() throws Exception {
        mockMvc.perform(get("/api/posts/9999"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value("error"))
                .andExpect(jsonPath("$.message", containsString("Post not found with ID: 9999")));
    }

    @Test
    @DisplayName("POST /api/posts - Valid input creates post and returns 201 Created")
    void createPost_ValidInput_Success() throws Exception {
        PostRequest request = new PostRequest("New Release Feature", "Details about Spring Boot 4.0 improvements.", "Dev Team");

        mockMvc.perform(post("/api/posts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.message").value("Post created successfully"))
                .andExpect(jsonPath("$.data.id").isNumber())
                .andExpect(jsonPath("$.data.title").value("New Release Feature"))
                .andExpect(jsonPath("$.data.status").value("DRAFT"));
    }

    @Test
    @DisplayName("POST /api/posts - Invalid input triggers Bean Validation and returns 400 with field errors")
    void createPost_InvalidInput_ValidationFailure() throws Exception {
        PostRequest invalidRequest = new PostRequest("", "", "");

        mockMvc.perform(post("/api/posts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value("error"))
                .andExpect(jsonPath("$.message").value("Validation failed"))
                .andExpect(jsonPath("$.data.title").isNotEmpty())
                .andExpect(jsonPath("$.data.content").isNotEmpty())
                .andExpect(jsonPath("$.data.author").isNotEmpty());
    }

    @Test
    @DisplayName("PUT /api/posts/{id} - Update existing post")
    void updatePost_Success() throws Exception {
        PostRequest updateReq = new PostRequest("Updated Post Title", "Updated post body content.", "Editor");

        mockMvc.perform(put("/api/posts/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateReq)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data.id").value(1))
                .andExpect(jsonPath("$.data.title").value("Updated Post Title"));
    }

    @Test
    @DisplayName("POST /api/posts/{id}/schedule - Schedule post with valid future date")
    void schedulePost_FutureDate_Success() throws Exception {
        LocalDateTime future = LocalDateTime.now().plusDays(5).withNano(0);
        SchedulePostRequest scheduleReq = new SchedulePostRequest(future);

        mockMvc.perform(post("/api/posts/1/schedule")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(scheduleReq)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("success"))
                .andExpect(jsonPath("$.data.status").value("SCHEDULED"))
                .andExpect(jsonPath("$.data.scheduledAt").isNotEmpty());
    }

    @Test
    @DisplayName("POST /api/posts/{id}/schedule - Past date rejected by @Future validation")
    void schedulePost_PastDate_ValidationFailure() throws Exception {
        LocalDateTime past = LocalDateTime.now().minusDays(1).withNano(0);
        SchedulePostRequest pastReq = new SchedulePostRequest(past);

        mockMvc.perform(post("/api/posts/1/schedule")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(pastReq)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value("error"))
                .andExpect(jsonPath("$.data.scheduledAt").value("Scheduled time must be in the future"));
    }

    @Test
    @DisplayName("Observability: Custom X-Correlation-Id header propagated to response")
    void customCorrelationId_PreservedInResponse() throws Exception {
        String customId = "trace-custom-uuid-12345";

        mockMvc.perform(get("/api/posts")
                        .header("X-Correlation-Id", customId))
                .andExpect(status().isOk())
                .andExpect(header().string("X-Correlation-Id", customId))
                .andExpect(jsonPath("$.correlationId").value(customId));
    }
}
