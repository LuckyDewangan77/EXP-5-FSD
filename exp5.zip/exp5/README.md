# Experiment 5: Spring Boot REST API Design & Exception Handling

## Aim
Design RESTful APIs using Spring Boot that enforce consistent response structures, handle exceptions globally, log request details with correlation-based tracing, and support secure cross-origin communication.

---

## Architecture Overview

```
+-----------------------------------------------------------------------------------+
|                              Client / Browser / React UI                          |
+-----------------------------------------------------------------------------------+
                                         │
                   HTTP Request (optional X-Correlation-Id)
                                         ▼
+-----------------------------------------------------------------------------------+
|                     LoggingFilter (OncePerRequestFilter)                          |
|  - Intercepts requests                                                            |
|  - Starts latency timer                                                           |
|  - Logs URI, HTTP Method, Response Status, and Execution Duration                 |
+-----------------------------------------------------------------------------------+
                                         │
                                         ▼
+-----------------------------------------------------------------------------------+
|               CorrelationInterceptor (HandlerInterceptor)                         |
|  - Generates or extracts X-Correlation-Id UUID                                    |
|  - Populates SLF4J MDC ("correlationId")                                          |
|  - Injects X-Correlation-Id into HTTP Response Header                             |
|  - Cleans up MDC on request completion (MDC.clear())                              |
+-----------------------------------------------------------------------------------+
                                         │
                                         ▼
+-----------------------------------------------------------------------------------+
|                          PostController (@RestController)                         |
|  - Validates incoming DTOs using @Valid (Bean Validation)                         |
|  - Defines RESTful resource endpoints (/api/posts)                                |
|  - Enforces CORS policies (@CrossOrigin & WebMvcConfigurer)                       |
+-----------------------------------------------------------------------------------+
               │                                                     │
       (Normal Flow)                                          (Exception Flow)
               ▼                                                     ▼
+-----------------------------+               +-------------------------------------+
|        PostService          |               |       GlobalExceptionHandler        |
|  - Business logic           |               |       (@RestControllerAdvice)       |
|  - State transitions        |               |  - MethodArgumentNotValidException  |
|  - Scheduled date checks    |               |  - ResourceNotFoundException        |
+-----------------------------+               |  - InvalidScheduleException         |
               │                              |  - Exception (Catch-all)            |
               ▼                              +-------------------------------------+
+-----------------------------+                                      │
|       PostRepository        |                                      │
|  - Thread-safe persistence  |                                      │
+-----------------------------+                                      │
               │                                                     │
               ▼                                                     ▼
+-----------------------------------------------------------------------------------+
|                       Standardized ApiResponse<T> Wrapper                         |
|       { "status": "...", "message": "...", "data": ..., "correlationId": "..." }  |
+-----------------------------------------------------------------------------------+
```

---

## Theoretical Principles Covered

### 1. REST API Design Principles
- **Statelessness**: Every request contains all required information; the server stores no client session state.
- **Resource-Based URIs**: Resources are modeled as entities:
  - `/api/posts` (Collection)
  - `/api/posts/{id}` (Individual resource)
- **HTTP Methods Semantics**:
  - `GET`: Safe, idempotent retrieval
  - `POST`: Resource creation / action execution
  - `PUT`: Idempotent resource replacement / update
  - `DELETE`: Idempotent resource removal
- **Uniform Interface**: Every response conforms to a standardized `ApiResponse<T>` envelope.

### 2. Layered Architecture (Separation of Concerns)
- **Controller Layer (`PostController`)**: Handles HTTP requests, request mappings, input validation triggering, and status code negotiation.
- **Service Layer (`PostService`, `PostServiceImpl`)**: Contains business rules, state transition validation, and domain manipulation.
- **Repository Layer (`PostRepository`, `InMemoryPostRepository`)**: Thread-safe data persistence using `ConcurrentHashMap` and atomic counters.

### 3. Bean Validation (Design by Contract - DbC)
- Input constraints enforced using Jakarta validation annotations on `PostRequest` and `SchedulePostRequest`:
  - `@NotBlank(message = "Title must not be empty")`
  - `@Size(min = 3, max = 100, message = "Title must be between 3 and 100 characters")`
  - `@NotBlank(message = "Content must not be empty")`
  - `@Size(max = 280, message = "Content exceeds limit of 280 characters")`
  - `@NotNull(message = "Scheduled time must not be null")`
  - `@Future(message = "Scheduled time must be in the future")`

### 4. API Response Standardization
All responses adhere to the standard envelope:
```json
{
  "status": "success",
  "message": "Post created successfully",
  "data": { ... },
  "timestamp": "2026-09-07T11:10:19.7282376",
  "correlationId": "f5b25672-0b86-4f17-a8d3-883984fe026d"
}
```

### 5. Cross-Origin Resource Sharing (CORS)
- Controller-level `@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173"})`.
- Global configuration via `WebMvcConfig` configuring allowed origins, headers, credentials, and exposing `X-Correlation-Id`.

### 6. Observability & Tracing (SLF4J MDC & Filters)
- `CorrelationInterceptor`: Injects/propagates `correlationId` into `org.slf4j.MDC` for every request and adds `X-Correlation-Id` to response headers.
- `LoggingFilter`: Extends `OncePerRequestFilter` to log URI, method, HTTP status code, and latency in milliseconds.
- `application.properties`: Logback pattern formats console logs with `[%X{correlationId}]`.

### 7. Centralized Exception Handling (`@RestControllerAdvice`)
- `GlobalExceptionHandler` intercepts all runtime and validation exceptions across the application:
  - `MethodArgumentNotValidException` $\rightarrow$ `400 Bad Request` with field error map.
  - `ResourceNotFoundException` $\rightarrow$ `404 Not Found`.
  - `InvalidScheduleException` $\rightarrow$ `400 Bad Request`.
  - `HttpRequestMethodNotSupportedException` $\rightarrow$ `405 Method Not Allowed`.
  - `Exception` $\rightarrow$ `500 Internal Server Error`.

---

## API Endpoints Reference

| Method | Endpoint | Description | Request Body | Response Status |
| :--- | :--- | :--- | :--- | :--- |
| `GET` | `/api/posts` | Retrieve all posts (supports `status` & `search` query params) | None | `200 OK` |
| `GET` | `/api/posts/{id}` | Retrieve post by ID | None | `200 OK` / `404 Not Found` |
| `POST` | `/api/posts` | Create new post | `PostRequest` | `201 Created` / `400 Bad Request` |
| `PUT` | `/api/posts/{id}` | Update existing post | `PostRequest` | `200 OK` / `404 Not Found` |
| `DELETE` | `/api/posts/{id}` | Delete post by ID | None | `200 OK` / `404 Not Found` |
| `POST` | `/api/posts/{id}/schedule` | Schedule post for future publication | `SchedulePostRequest` | `200 OK` / `400 Bad Request` |
| `POST` | `/api/posts/{id}/publish` | Immediately publish post | None | `200 OK` / `404 Not Found` |

---

## Running on Localhost

### 1. Prerequisites
- Java 21 or Java 26 installed.
- Maven Wrapper is bundled inside `backend/` (`mvnw.cmd`).

### 2. Start the Server
Navigate to `backend/` and run:
```powershell
cd backend
.\mvnw.cmd spring-boot:run
```
Alternatively, build and run the packaged jar:
```powershell
.\mvnw.cmd package -DskipTests=true
java -jar target/exp5-rest-api-0.0.1-SNAPSHOT.jar
```
The server will start on `http://localhost:8080`.

### 3. Access the Interactive Dashboard
Open your browser and navigate to:
```
http://localhost:8080/
```
The web dashboard provides:
- Live Post CRUD management
- Live datetime picker for scheduling
- Real-time exception & validation trigger buttons
- Live Request/Response Inspector with latency and `X-Correlation-Id` tracking

---

## Running Automated Tests

Run the full suite of unit and integration tests (`MockMvc`):
```powershell
cd backend
.\mvnw.cmd test
```
All 10 tests will execute, validating CRUD operations, validation failures, scheduling logic, correlation headers, and global exception responses.

---

## Sample cURL / PowerShell Commands

### 1. Create a Post (Valid)
```powershell
Invoke-RestMethod -Uri "http://localhost:8080/api/posts" -Method POST -ContentType "application/json" -Body '{"title":"Clean Code Architecture","content":"Designing robust and maintainable RESTful services with Spring Boot.","author":"Robert C. Martin"}'
```

### 2. Trigger Bean Validation Failure (Blank content & short title)
```powershell
Invoke-RestMethod -Uri "http://localhost:8080/api/posts" -Method POST -ContentType "application/json" -Body '{"title":"","content":"","author":""}'
```

### 3. Schedule a Post
```powershell
Invoke-RestMethod -Uri "http://localhost:8080/api/posts/1/schedule" -Method POST -ContentType "application/json" -Body '{"scheduledAt":"2026-11-20T14:00:00"}'
```

### 4. Fetch Post with Custom Correlation ID Header
```powershell
curl.exe -i "http://localhost:8080/api/posts" -H "X-Correlation-Id: client-trace-9999"
```
